<?php
die('sadasdsa');
?>