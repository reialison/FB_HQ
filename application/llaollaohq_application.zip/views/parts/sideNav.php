              
                <!-- sidebar: style can be found in sidebar.less -->
              <section class="sidebar">
              <div class="page-sidebar-wrapper">
                    <div class="page-sidebar navbar-collapse collapse">
                        <ul class="page-sidebar-menu  page-header-fixed  page-sidebar-menu-light " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="150" >
                            
                            <?php
                                if(isset($sideNav))
                                  echo $sideNav;
                            ?>
                            <div class="menu-toggler sidebar-toggler"> </div>
                        </ul>
                    </div>
                </div>
                    <!-- /.sidebar -->
         