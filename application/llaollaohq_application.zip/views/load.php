<?php
	if(isset($load_js))
		$this->load->view('js/'.$load_js);
	$this->load->view('parts/load');
?>